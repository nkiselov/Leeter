import org.json.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.function.Predicate;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("result.json"));
        StringBuilder b = new StringBuilder();
        String ln;
        while((ln=br.readLine())!=null){
            b.append(ln);
        }
        String json = b.toString();
        JSONObject obj = new JSONObject(json);
        JSONArray qarr = obj.getJSONObject("data").getJSONObject("problemsetQuestionList").getJSONArray("questions");
        Question[] questionsOrig = new Question[qarr.length()];
        for(int i=0; i<qarr.length(); i++){
            questionsOrig[i] = new Question(qarr.getJSONObject(i));
        }
        Question[] questions = Arrays.stream(questionsOrig).filter(new Predicate<Question>() {
            @Override
            public boolean test(Question question) {
                return question.difficulty == Difficulty.Hard;
            }
        }).toArray(Question[]::new);
        Arrays.sort(questions, (o1, o2) -> (int)Math.signum(o2.score-o1.score));
        int y = 0;
    }
}