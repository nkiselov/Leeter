import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class LoadLeet {
    private static final String cookie = "87b5a3c3f1a55520_gr_cs1=NikitaK20546; 87b5a3c3f1a55520_gr_last_sent_cs1=NikitaK20546; 87b5a3c3f1a55520_gr_last_sent_sid_with_cs1=576a2fdf-904c-46e0-8a85-f3bf145dd784; 87b5a3c3f1a55520_gr_session_id=576a2fdf-904c-46e0-8a85-f3bf145dd784; 87b5a3c3f1a55520_gr_session_id_576a2fdf-904c-46e0-8a85-f3bf145dd784=true; _ga=GA1.2.493961829.1644122565; _gid=GA1.2.1842812873.1653155784; gr_user_id=80f107d3-f16c-4017-896b-69069cb72096; csrftoken=6pxAWVjiXUshgu163CAd3dZ0HwWprkdhqTh15dyiarrN6yx15T1tj1fWm6TapDyx; _gat=1; c_a_u=TmlraXRhSzIwNTQ2:1nsuFY:2Pfi-JLIiybTO_A9tLQIqBGcDb4; __atuvc=5%7C17%2C6%7C18%2C10%7C19%2C11%7C20%2C1%7C21; NEW_PROBLEMLIST_PAGE=1; LEETCODE_SESSION=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJfYXV0aF91c2VyX2lkIjoiMzU4MDYwMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYmQ2NjRhOWNmMzJmMTIwYWM5MTMxMjRiNGQxYjUyOTdlYmMzZDI1MiIsImlkIjozNTgwNjAwLCJlbWFpbCI6Im5pa2l0YUB2YW1yYWQuY29tIiwidXNlcm5hbWUiOiJOaWtpdGFLMjA1NDYiLCJ1c2VyX3NsdWciOiJOaWtpdGFLMjA1NDYiLCJhdmF0YXIiOiJodHRwczovL3MzLXVzLXdlc3QtMS5hbWF6b25hd3MuY29tL3MzLWxjLXVwbG9hZC9hc3NldHMvZGVmYXVsdF9hdmF0YXIuanBnIiwicmVmcmVzaGVkX2F0IjoxNjUzMTU1NzgzLCJpcCI6IjEwOC4xNi40Ni4yMjQiLCJpZGVudGl0eSI6ImM0MGMwYWMxYjNjZWE4NDk2MzkzYmQ2MjE1ZmQwNWVkIiwiX3Nlc3Npb25fZXhwaXJ5IjoxMjA5NjAwLCJzZXNzaW9uX2lkIjoyMDk1ODUyMn0.siXRfBog9aBqr5KA6R7P3C2eD2l-IEHkzcYnye9hiic";

    public static void main(String[] args) throws IOException{
        URL url = new URL("https://leetcode.com/graphql/");
        HttpsURLConnection http = (HttpsURLConnection) url.openConnection();
        http.setRequestMethod("POST");
        http.setDoOutput(true);
        http.setRequestProperty("Accept", "application/json");
        http.setRequestProperty("Cookie",cookie);
        http.setRequestProperty("Content-Type", "application/json");

        String data = "{\"query\":\"\\n    query problemsetQuestionList($categorySlug: String, $limit: Int, $skip: Int, $filters: QuestionListFilterInput) {\\n  problemsetQuestionList: questionList(\\n    categorySlug: $categorySlug\\n    limit: $limit\\n    skip: $skip\\n    filters: $filters\\n  ) {\\n    total: totalNum\\n    questions: data {\\n      acRate\\n      difficulty\\n      likes\\n    dislikes\\n   frontendQuestionId: questionFrontendId\\n      isFavor\\n      paidOnly: isPaidOnly\\n      status\\n      title\\n      titleSlug\\n      topicTags {\\n        name\\n        id\\n        slug\\n      }\\n      hasSolution\\n      hasVideoSolution\\n    }\\n  }\\n}\\n    \",\"variables\":{\"categorySlug\":\"\",\"skip\":0,\"limit\":3000,\"filters\":{}}}";

        byte[] out = data.getBytes(StandardCharsets.UTF_8);

        OutputStream stream = http.getOutputStream();
        stream.write(out);

        System.out.println(http.getResponseCode() + " " + http.getResponseMessage());
        OutputStream os = new FileOutputStream(new File("result.json"));
        http.getInputStream().transferTo(os);
        http.disconnect();
    }
}
