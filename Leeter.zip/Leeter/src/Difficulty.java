public enum Difficulty {
    Easy,Medium,Hard
}
